from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator
from datetime import datetime

with DAG('as400_etl_dag',
         start_date=datetime(2023, 1, 1),
         schedule_interval='@daily',
         catchup=False) as dag:

    start = DummyOperator(task_id='start')

    run_dataflow = DataflowTemplatedJobStartOperator(
        task_id='run_dataflow',
        template='gs://dataflow-templates/latest/Word_Count',
        parameters={'inputFile': 'gs://bucket/input.txt', 'output': 'gs://bucket/output'},
        location='us-central1'
    )

    end = DummyOperator(task_id='end')

    start >> run_dataflow >> end